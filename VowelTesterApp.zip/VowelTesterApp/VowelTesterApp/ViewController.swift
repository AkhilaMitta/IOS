//
//  ViewController.swift
//  VowelTesterApp
//
//  Created by Mitta,Akhila on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var TextInput: UITextField!
    
    
    
    @IBOutlet weak var Label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func OutputBTN(_ sender: Any) {
        var input = TextInput.text!
        
        var input1 = input.lowercased()
        
        if(input1.contains("a") || input1.contains("e") || input1.contains("i") || input1.contains("o") || input1.contains("u")){
            Label.text = "The entered text is a vowel🙂"
        }
        else{
            Label.text = "The entered text is not a vowel☹️"
        }
    
        
        
    }
    
}

