//
//  ViewController.swift
//  SamplePracticeApp
//
//  Created by Mitta,Akhila on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var course1outlet: UITextField!
    
    @IBOutlet weak var course2outlet: UITextField!
    
    @IBOutlet weak var displaylabeloutput: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonclick(_ sender: Any) {
        //read the course1 name and store it in a variable
        var course1name = course1outlet.text!;
        
        
        //read the course2 name and store it in a variable
        var course2name = course2outlet.text!;
        
        //perform string interpollation/concatination and assign it to display. (course1 - course2)
        displaylabeloutput.text = "\(course1name) - \(course2name)"
    }
    
}

