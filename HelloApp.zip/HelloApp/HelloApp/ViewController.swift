//
//  ViewController.swift
//  HelloApp
//
//  Created by Mitta,Akhila on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputoutlet: UITextField!
    
    
    
    @IBOutlet weak var displaylabeloutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    @IBAction func buttonclicked(_ sender: UIButton) {
        // read the input and store it(assign it to a variable)
        var input = inputoutlet.text!
        
        //perform string interpolation
        displaylabeloutlet.text = "Hello, \(input)!"
    }
    
}

