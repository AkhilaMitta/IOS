//
//  ViewController.swift
//  ClimateApp
//
//  Created by Mitta,Akhila on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
   
    @IBOutlet weak var temperatureoutlet: UITextField!
    
    
    
    @IBOutlet weak var imageoutlet: UIImageView!
    
    
    @IBOutlet weak var LabelOutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func displaybutton(_ sender: Any) {
        var temp = Double(temperatureoutlet.text!)!
        if(temp<5){
            imageoutlet.image = UIImage(named:"snow")
            LabelOutlet.text! = "its snowy🥶!!"
        }
        else if(temp>5 && temp<24){
            imageoutlet.image = UIImage(named:"fall")
            LabelOutlet.text! = "its warm☺️!!"
        }
        else{
            imageoutlet.image = UIImage(named:"sunny")
            LabelOutlet.text! = "its hot🥵!!"
        }
        
    }
}

