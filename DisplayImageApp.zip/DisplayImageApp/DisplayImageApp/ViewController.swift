//
//  ViewController.swift
//  DisplayImageApp
//
//  Created by Mitta,Akhila on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var DescriptionLabelOutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func DisplayImage(_ sender: Any) {
        //display the image
        ImageViewOutlet.image = UIImage(named:"tajmahal")
        //display the text in label
        DescriptionLabelOutlet.text = "The Beautiful view of TajMahal"
        
        
        
        
    }
    
}

